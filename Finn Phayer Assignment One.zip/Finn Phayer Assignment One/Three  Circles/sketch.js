function setup() {
  createCanvas(400, 400);
}
function draw(){
  background(255);
  noStroke();
  
  fill(255,0,0,75);
  circle(200,140,100);
  
  fill(0,255,0,75);
  circle(234,200,100);
  
  fill(0,0,255,75);
  circle(166,200,100);
}[]
