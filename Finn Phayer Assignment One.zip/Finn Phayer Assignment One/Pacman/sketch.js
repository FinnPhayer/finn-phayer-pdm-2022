function setup() {
  createCanvas(400, 200);
}

function draw(){
  background(0);
  fill(255,255,0);
  arc(100,100,150,150, PI + QUARTER_PI, 3 * QUARTER_PI );
  fill(255,0,0);
  rect(250,100,125,75);
  noStroke();
  circle(312.5,100,125);
  fill(255);
  circle(280,100,40);
  circle(345,100,40);
  fill(0,0,255);
  circle(280,100,25);
  circle(345,100,25);
  
}