function setup() {
  createCanvas(400, 200);
}

function draw() {
  background(100,200,0);
  ellipse(100,100,150,150);
  rectMode(CENTER);
  rect(300,100,150,150);
}