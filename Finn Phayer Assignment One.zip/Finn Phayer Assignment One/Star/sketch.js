function setup() {
  createCanvas(400, 400);
}

function draw(){
  background(0,0,175);
  strokeWeight(5);
  stroke(255);
  fill(0,200,0);
  circle(200,200,200);
  
  fill(200,0,0);
  beginShape();
  vertex(200,100);
  vertex(230,170);
  vertex(300,170);
  vertex(240,210);
  vertex(260,280);
  vertex(200,240);
  vertex(140,280);
  vertex(160,210)
  vertex(100,170);
  vertex(170,170)
  endShape(CLOSE);
}